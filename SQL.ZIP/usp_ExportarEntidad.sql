/* ============================================================
   usp_ExportarEntidad
   SQL Server 2014

   Genera un script .sql con los INSERT de una entidad completa
   (cabecera, detalle y tablas relacionadas) para reproducirla
   en otra base/PC.

   La lista de tablas esta hardcodeada en el bloque
   "LISTA DE TABLAS DE LA ENTIDAD". Solo hay que escribir
   esquema + nombre de tabla. El SP calcula solo:

     - la PK de la tabla raiz (la PRIMERA tabla de la lista),
     - las columnas de cada tabla,
     - el camino de FK desde cada tabla hasta la raiz,
     - el SELECT con sus JOIN y el filtro por el ID,
     - el orden de insercion (topological sort / algoritmo de Kahn),
     - los SET IDENTITY_INSERT ON/OFF y el DBCC CHECKIDENT RESEED.

   Reglas:
     - La PRIMERA tabla de la lista es la raiz de la entidad.
     - La PK de la raiz debe ser de una sola columna (normalmente
       el identity). Si es compuesta, un solo @IdEntidad no alcanza.
     - Cada tabla de la lista debe tener un camino de FK
       hijo -> padre -> ... -> raiz. Las tablas catalogo (sin ese
       camino) deben quedar fuera de la lista.
     - Se excluyen columnas calculadas y rowversion/timestamp.
     - Se conservan los IDs originales (misma copia, sin remapeo).
     - Si una tabla tiene mas de una FK hacia la misma tabla padre,
       el SP elige un camino. Conviene revisar el script generado.

   Uso:
       DECLARE @s nvarchar(max);
       EXEC dbo.usp_ExportarEntidad @IdEntidad = 12345, @Script = @s OUTPUT;
       SELECT @s;
   ============================================================ */

IF OBJECT_ID('dbo.usp_ExportarEntidad', 'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_ExportarEntidad;
GO

-- Necesario para los metodos XML (.value) que usa el SP
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE PROCEDURE dbo.usp_ExportarEntidad
    @IdEntidad int,
    @Script    nvarchar(max) = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    /* ============================================================
       LISTA DE TABLAS DE LA ENTIDAD (hardcodeada)

       Solo esquema + tabla. La PRIMERA es la tabla raiz/cabecera.
       No hace falta escribir columnas ni SELECT de cada tabla.
       ============================================================ */
    DECLARE @Tablas TABLE (
        Id         int IDENTITY(1,1) PRIMARY KEY,
        Esquema    sysname       NOT NULL,
        Tabla      sysname       NOT NULL,
        InDegree   int           NOT NULL DEFAULT(0),
        OrdenFinal int           NULL,
        SelectSql  nvarchar(max) NULL,
        UNIQUE (Esquema, Tabla)
    );

    INSERT INTO @Tablas (Esquema, Tabla) VALUES
    (N'dbo', N'Pedido'),
    (N'dbo', N'PedidoDetalle'),
    (N'dbo', N'PedidoDetalleImpuesto'),
    (N'dbo', N'PedidoObservacion');

    /* ============================================================
       RAIZ = PRIMERA TABLA DE LA LISTA
       ============================================================ */
    DECLARE @IdRaiz      int,
            @EsquemaRaiz sysname,
            @TablaRaiz   sysname,
            @ObjetoRaiz  int,
            @PkRaiz      sysname;

    SELECT @IdRaiz = MIN(Id) FROM @Tablas;

    SELECT @EsquemaRaiz = Esquema, @TablaRaiz = Tabla
    FROM @Tablas
    WHERE Id = @IdRaiz;

    SET @ObjetoRaiz = OBJECT_ID(QUOTENAME(@EsquemaRaiz) + N'.' + QUOTENAME(@TablaRaiz));

    /* Validar que las tablas de la lista existan */
    IF EXISTS (
        SELECT 1
        FROM @Tablas
        WHERE OBJECT_ID(QUOTENAME(Esquema) + N'.' + QUOTENAME(Tabla), 'U') IS NULL
    )
    BEGIN
        DECLARE @Faltan nvarchar(2048);

        SELECT @Faltan = N'No existen estas tablas: ' + STUFF((
            SELECT N', ' + QUOTENAME(Esquema) + N'.' + QUOTENAME(Tabla)
            FROM @Tablas
            WHERE OBJECT_ID(QUOTENAME(Esquema) + N'.' + QUOTENAME(Tabla), 'U') IS NULL
            ORDER BY Esquema, Tabla
            FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N'');

        THROW 50010, @Faltan, 1;
    END

    /* ============================================================
       PRIMARY KEY DE LA RAIZ
       ============================================================ */
    DECLARE @PkCols TABLE (
        Ord int    NOT NULL,
        Col sysname NOT NULL
    );

    INSERT INTO @PkCols (Ord, Col)
    SELECT ic.key_ordinal, c.name
    FROM sys.key_constraints kc
    JOIN sys.index_columns ic
      ON ic.object_id = kc.parent_object_id
     AND ic.index_id  = kc.unique_index_id
    JOIN sys.columns c
      ON c.object_id = ic.object_id
     AND c.column_id = ic.column_id
    WHERE kc.parent_object_id = @ObjetoRaiz
      AND kc.type = 'PK';

    IF NOT EXISTS (SELECT 1 FROM @PkCols)
        THROW 50011, 'La tabla raiz no tiene PRIMARY KEY.', 1;

    IF (SELECT COUNT(*) FROM @PkCols) > 1
        THROW 50012, 'La PRIMARY KEY de la tabla raiz es compuesta. Se espera una sola columna.', 1;

    SELECT @PkRaiz = Col FROM @PkCols;

    /* ============================================================
       RELACIONES FK ENTRE LAS TABLAS DE LA LISTA
       ============================================================ */
    DECLARE @Fk TABLE (
        IdEdge     int IDENTITY(1,1) PRIMARY KEY,
        FkObjectId int     NOT NULL,
        IdHijo     int     NOT NULL,
        IdPadre    int     NOT NULL
    );

    DECLARE @FkCol TABLE (
        IdEdge   int     NOT NULL,
        Ord      int     NOT NULL,
        ColHijo  sysname NOT NULL,
        ColPadre sysname NOT NULL,
        PRIMARY KEY (IdEdge, Ord)
    );

    -- parent_object_id      = tabla hija (la que tiene la FK)
    -- referenced_object_id  = tabla padre (la que se referencia)
    -- Se excluyen las FK de una tabla consigo misma.
    INSERT INTO @Fk (FkObjectId, IdHijo, IdPadre)
    SELECT fk.object_id, c.Id, p.Id
    FROM sys.foreign_keys fk
    JOIN sys.tables  tc ON tc.object_id = fk.parent_object_id
    JOIN sys.schemas sc ON sc.schema_id = tc.schema_id
    JOIN sys.tables  tp ON tp.object_id = fk.referenced_object_id
    JOIN sys.schemas sp ON sp.schema_id = tp.schema_id
    JOIN @Tablas c ON c.Esquema = sc.name AND c.Tabla = tc.name
    JOIN @Tablas p ON p.Esquema = sp.name AND p.Tabla = tp.name
    WHERE c.Id <> p.Id;

    INSERT INTO @FkCol (IdEdge, Ord, ColHijo, ColPadre)
    SELECT f.IdEdge,
           fkc.constraint_column_id,
           cc.name,
           cp.name
    FROM @Fk f
    JOIN sys.foreign_key_columns fkc
      ON fkc.constraint_object_id = f.FkObjectId
    JOIN sys.columns cc
      ON cc.object_id = fkc.parent_object_id
     AND cc.column_id = fkc.parent_column_id
    JOIN sys.columns cp
      ON cp.object_id = fkc.referenced_object_id
     AND cp.column_id = fkc.referenced_column_id;

    /* ============================================================
       ORDEN AUTOMATICO POR FK (topological sort / Kahn)
       ============================================================ */
    DECLARE @Aristas TABLE (
        IdPadre int NOT NULL,
        IdHijo  int NOT NULL,
        PRIMARY KEY (IdPadre, IdHijo)
    );

    INSERT INTO @Aristas (IdPadre, IdHijo)
    SELECT DISTINCT IdPadre, IdHijo FROM @Fk;

    UPDATE t
    SET InDegree = (SELECT COUNT(*) FROM @Aristas a WHERE a.IdHijo = t.Id)
    FROM @Tablas t;

    DECLARE @IdActual int, @NroOrden int = 0;

    WHILE 1 = 1
    BEGIN
        SET @IdActual = NULL;

        -- siguiente tabla sin dependencias pendientes (desempate alfabetico)
        SELECT TOP (1) @IdActual = Id
        FROM @Tablas
        WHERE OrdenFinal IS NULL AND InDegree = 0
        ORDER BY Esquema, Tabla;

        IF @IdActual IS NULL BREAK;

        SET @NroOrden += 1;
        UPDATE @Tablas SET OrdenFinal = @NroOrden WHERE Id = @IdActual;

        -- quitar las aristas que salian de esta tabla
        DELETE FROM @Aristas WHERE IdPadre = @IdActual;

        UPDATE t
        SET InDegree = (SELECT COUNT(*) FROM @Aristas a WHERE a.IdHijo = t.Id)
        FROM @Tablas t
        WHERE t.OrdenFinal IS NULL;
    END

    -- si quedaron tablas sin orden, hay un ciclo de FK
    IF EXISTS (SELECT 1 FROM @Tablas WHERE OrdenFinal IS NULL)
    BEGIN
        DECLARE @Ciclo nvarchar(2048);

        SELECT @Ciclo = N'Dependencias circulares entre: ' + STUFF((
            SELECT N', ' + QUOTENAME(Esquema) + N'.' + QUOTENAME(Tabla)
            FROM @Tablas
            WHERE OrdenFinal IS NULL
            ORDER BY Esquema, Tabla
            FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N'');

        THROW 50013, @Ciclo, 1;
    END

    /* ============================================================
       CAMINO DE FK DESDE CADA TABLA HASTA LA RAIZ
       ============================================================ */
    DECLARE @Caminos TABLE (
        IdTabla     int          NOT NULL,
        NodoActual  int          NOT NULL,
        Profundidad int          NOT NULL,
        Edges       varchar(max) NOT NULL
    );

    ;WITH cte AS (
        SELECT Id AS IdTabla,
               Id AS NodoActual,
               0  AS Profundidad,
               CAST('' AS varchar(max)) AS Edges
        FROM @Tablas

        UNION ALL

        SELECT r.IdTabla,
               f.IdPadre,
               r.Profundidad + 1,
               CASE WHEN r.Edges = '' THEN CAST(f.IdEdge AS varchar(20))
                    ELSE r.Edges + ',' + CAST(f.IdEdge AS varchar(20))
               END
        FROM cte r
        JOIN @Fk f ON f.IdHijo = r.NodoActual
        WHERE r.Profundidad < 50
    )
    INSERT INTO @Caminos (IdTabla, NodoActual, Profundidad, Edges)
    SELECT IdTabla, NodoActual, Profundidad, Edges
    FROM cte
    OPTION (MAXRECURSION 100);

    -- se queda con el camino mas corto que llega a la raiz
    DECLARE @Ruta TABLE (
        IdTabla     int PRIMARY KEY,
        Profundidad int          NOT NULL,
        Edges       varchar(max) NOT NULL
    );

    INSERT INTO @Ruta (IdTabla, Profundidad, Edges)
    SELECT IdTabla, Profundidad, Edges
    FROM (
        SELECT IdTabla,
               Profundidad,
               Edges,
               ROW_NUMBER() OVER (PARTITION BY IdTabla
                                  ORDER BY Profundidad, Edges) AS rn
        FROM @Caminos
        WHERE NodoActual = @IdRaiz
    ) x
    WHERE rn = 1;

    -- toda tabla de la lista tiene que llegar a la raiz
    IF EXISTS (
        SELECT 1
        FROM @Tablas t
        WHERE NOT EXISTS (SELECT 1 FROM @Ruta r WHERE r.IdTabla = t.Id)
    )
    BEGIN
        DECLARE @SinRuta nvarchar(2048);

        SELECT @SinRuta = N'Sin camino de FK hasta la raiz '
                        + QUOTENAME(@EsquemaRaiz) + N'.' + QUOTENAME(@TablaRaiz)
                        + N': ' + STUFF((
            SELECT N', ' + QUOTENAME(t.Esquema) + N'.' + QUOTENAME(t.Tabla)
            FROM @Tablas t
            WHERE NOT EXISTS (SELECT 1 FROM @Ruta r WHERE r.IdTabla = t.Id)
            ORDER BY t.Esquema, t.Tabla
            FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N'');

        THROW 50014, @SinRuta, 1;
    END

    /* ============================================================
       ARMADO AUTOMATICO DEL SELECT DE CADA TABLA
       ============================================================ */
    DECLARE @Pasos TABLE (
        Paso   int PRIMARY KEY,
        IdEdge int NOT NULL
    );

    DECLARE @IdT        int,
            @EsqT       sysname,
            @TabT       sysname,
            @FullT      nvarchar(300),
            @RutaEdges  varchar(max),
            @ColsSel    nvarchar(max),
            @Joins      nvarchar(max),
            @On         nvarchar(max),
            @Where      nvarchar(max),
            @Paso       int,
            @MaxPaso    int,
            @IdEdge     int,
            @EsqPadre   sysname,
            @TabPadre   sysname,
            @AliasPadre varchar(20),
            @AliasHijo  varchar(20),
            @AliasUlt   varchar(20),
            @Resto      varchar(max),
            @Coma       int;

    DECLARE curTab CURSOR LOCAL FAST_FORWARD FOR
        SELECT t.Id, t.Esquema, t.Tabla, r.Edges
        FROM @Tablas t
        JOIN @Ruta r ON r.IdTabla = t.Id
        ORDER BY t.Id;

    OPEN curTab;
    FETCH NEXT FROM curTab INTO @IdT, @EsqT, @TabT, @RutaEdges;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @FullT = QUOTENAME(@EsqT) + N'.' + QUOTENAME(@TabT);

        /* Columnas: todas menos calculadas y rowversion/timestamp.
           El orden (column_id) coincide con el que devuelve el SELECT. */
        SELECT @ColsSel = STUFF((
                   SELECT N',' + CHAR(13) + CHAR(10)
                          + N'       t0.' + QUOTENAME(c.name) + N' AS ' + QUOTENAME(c.name)
                   FROM sys.columns c
                   WHERE c.object_id = OBJECT_ID(@FullT)
                     AND c.is_computed = 0
                     AND c.system_type_id <> 189   -- 189 = timestamp/rowversion
                   ORDER BY c.column_id
                   FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 3, N'');

        IF @ColsSel IS NULL OR @ColsSel = N''
            THROW 50015, 'Una tabla de la lista no tiene columnas exportables.', 1;

        /* Armar los pasos del camino (lista de IdEdge: "12,7,...") */
        DELETE FROM @Pasos;

        IF @RutaEdges <> ''
        BEGIN
            SET @Resto = @RutaEdges;
            SET @Paso  = 0;

            WHILE LEN(@Resto) > 0
            BEGIN
                SET @Paso += 1;
                SET @Coma  = CHARINDEX(',', @Resto);

                IF @Coma = 0
                BEGIN
                    INSERT INTO @Pasos (Paso, IdEdge)
                    VALUES (@Paso, CAST(@Resto AS int));
                    SET @Resto = '';
                END
                ELSE
                BEGIN
                    INSERT INTO @Pasos (Paso, IdEdge)
                    VALUES (@Paso, CAST(LEFT(@Resto, @Coma - 1) AS int));
                    SET @Resto = SUBSTRING(@Resto, @Coma + 1, LEN(@Resto));
                END
            END
        END

        SELECT @MaxPaso = ISNULL(MAX(Paso), 0) FROM @Pasos;

        /* JOINs: t0 es la tabla, t1 su padre, t2 el padre de t1, ... */
        SET @Joins = N'';
        SET @Paso  = 1;

        WHILE @Paso <= @MaxPaso
        BEGIN
            SELECT @IdEdge = IdEdge FROM @Pasos WHERE Paso = @Paso;

            SELECT @EsqPadre = pt.Esquema, @TabPadre = pt.Tabla
            FROM @Fk f
            JOIN @Tablas pt ON pt.Id = f.IdPadre
            WHERE f.IdEdge = @IdEdge;

            SET @AliasPadre = 't' + CONVERT(varchar(10), @Paso);
            SET @AliasHijo  = 't' + CONVERT(varchar(10), @Paso - 1);

            SELECT @On = STUFF((
                       SELECT N' AND ' + @AliasPadre + N'.' + QUOTENAME(fc.ColPadre)
                              + N' = ' + @AliasHijo + N'.' + QUOTENAME(fc.ColHijo)
                       FROM @FkCol fc
                       WHERE fc.IdEdge = @IdEdge
                       ORDER BY fc.Ord
                       FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 5, N'');

            SET @Joins += CHAR(13) + CHAR(10)
                        + N'JOIN ' + QUOTENAME(@EsqPadre) + N'.' + QUOTENAME(@TabPadre)
                        + N' AS ' + @AliasPadre + N' ON ' + @On;

            SET @Paso += 1;
        END

        SET @AliasUlt = 't' + CONVERT(varchar(10), @MaxPaso);
        SET @Where    = N'WHERE ' + @AliasUlt + N'.' + QUOTENAME(@PkRaiz) + N' = {ID}';

        UPDATE @Tablas
        SET SelectSql = N'SELECT ' + @ColsSel + CHAR(13) + CHAR(10)
                       + N'FROM ' + @FullT + N' AS t0'
                       + @Joins + CHAR(13) + CHAR(10)
                       + @Where
        WHERE Id = @IdT;

        FETCH NEXT FROM curTab INTO @IdT, @EsqT, @TabT, @RutaEdges;
    END

    CLOSE curTab;
    DEALLOCATE curTab;

    /* ============================================================
       GENERACION DEL SCRIPT
       ============================================================ */
    DECLARE @Meta TABLE (
        Ord         int           NOT NULL,
        Col         nvarchar(128) NOT NULL,
        EsNullable  bit           NOT NULL,
        Expr        nvarchar(max) NOT NULL
    );

    DECLARE @Esquema sysname, @Tabla sysname, @SelectSql nvarchar(max);
    DECLARE @TieneIdentity bit, @Full nvarchar(300);
    DECLARE @Cols nvarchar(max), @ValsExpr nvarchar(max);
    DECLARE @Inserts nvarchar(max), @Sql nvarchar(max);
    DECLARE @Reseed nvarchar(max) = N'', @CatchOff nvarchar(max) = N'';

    SET @Script = N'/* Entidad Id=' + CONVERT(nvarchar(20), @IdEntidad)
                + N'  Generado ' + CONVERT(nvarchar(19), SYSDATETIME(), 120) + N' */' + CHAR(13)+CHAR(10)
                + N'SET NOCOUNT ON;' + CHAR(13)+CHAR(10)
                + N'SET XACT_ABORT ON;' + CHAR(13)+CHAR(10)
                + N'BEGIN TRY' + CHAR(13)+CHAR(10)
                + N'    BEGIN TRAN;' + CHAR(13)+CHAR(10);

    DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
        SELECT Esquema, Tabla, SelectSql
        FROM @Tablas
        ORDER BY OrdenFinal;

    OPEN cur;
    FETCH NEXT FROM cur INTO @Esquema, @Tabla, @SelectSql;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @SelectSql = REPLACE(@SelectSql, N'{ID}', CONVERT(nvarchar(20), @IdEntidad));
        SET @Full = QUOTENAME(@Esquema) + N'.' + QUOTENAME(@Tabla);

        -- identity: se detecta solo
        SELECT @TieneIdentity = CASE WHEN EXISTS (
                   SELECT 1 FROM sys.identity_columns WHERE object_id = OBJECT_ID(@Full)
               ) THEN 1 ELSE 0 END;

        DELETE FROM @Meta;

        -- metadatos de las columnas que devuelve el SELECT
        INSERT INTO @Meta (Ord, Col, EsNullable, Expr)
        SELECT column_ordinal,
               name,
               is_nullable,
               CASE LOWER(LEFT(system_type_name, CHARINDEX('(', system_type_name + '(') - 1))
                   WHEN 'bit'              THEN N'CONVERT(varchar(1), t.'  + QUOTENAME(name) + N')'
                   WHEN 'tinyint'          THEN N'CONVERT(varchar(3), t.'  + QUOTENAME(name) + N')'
                   WHEN 'smallint'         THEN N'CONVERT(varchar(6), t.'  + QUOTENAME(name) + N')'
                   WHEN 'int'              THEN N'CONVERT(varchar(11), t.' + QUOTENAME(name) + N')'
                   WHEN 'bigint'           THEN N'CONVERT(varchar(20), t.' + QUOTENAME(name) + N')'
                   WHEN 'decimal'          THEN N'CONVERT(varchar(50), t.' + QUOTENAME(name) + N')'
                   WHEN 'numeric'          THEN N'CONVERT(varchar(50), t.' + QUOTENAME(name) + N')'
                   WHEN 'money'            THEN N'CONVERT(varchar(50), t.' + QUOTENAME(name) + N')'
                   WHEN 'smallmoney'       THEN N'CONVERT(varchar(50), t.' + QUOTENAME(name) + N')'
                   WHEN 'float'            THEN N'LTRIM(RTRIM(STR(t.' + QUOTENAME(name) + N', 30, 17)))'
                   WHEN 'real'             THEN N'LTRIM(RTRIM(STR(t.' + QUOTENAME(name) + N', 30, 9)))'
                   WHEN 'char'             THEN N'N''N'' + NCHAR(39) + REPLACE(CONVERT(nvarchar(max), t.' + QUOTENAME(name) + N'), NCHAR(39), NCHAR(39)+NCHAR(39)) + NCHAR(39)'
                   WHEN 'varchar'          THEN N'N''N'' + NCHAR(39) + REPLACE(CONVERT(nvarchar(max), t.' + QUOTENAME(name) + N'), NCHAR(39), NCHAR(39)+NCHAR(39)) + NCHAR(39)'
                   WHEN 'nchar'            THEN N'N''N'' + NCHAR(39) + REPLACE(CONVERT(nvarchar(max), t.' + QUOTENAME(name) + N'), NCHAR(39), NCHAR(39)+NCHAR(39)) + NCHAR(39)'
                   WHEN 'nvarchar'         THEN N'N''N'' + NCHAR(39) + REPLACE(CONVERT(nvarchar(max), t.' + QUOTENAME(name) + N'), NCHAR(39), NCHAR(39)+NCHAR(39)) + NCHAR(39)'
                   WHEN 'text'             THEN N'N''N'' + NCHAR(39) + REPLACE(CONVERT(nvarchar(max), t.' + QUOTENAME(name) + N'), NCHAR(39), NCHAR(39)+NCHAR(39)) + NCHAR(39)'
                   WHEN 'ntext'            THEN N'N''N'' + NCHAR(39) + REPLACE(CONVERT(nvarchar(max), t.' + QUOTENAME(name) + N'), NCHAR(39), NCHAR(39)+NCHAR(39)) + NCHAR(39)'
                   WHEN 'xml'              THEN N'N''N'' + NCHAR(39) + REPLACE(CONVERT(nvarchar(max), t.' + QUOTENAME(name) + N'), NCHAR(39), NCHAR(39)+NCHAR(39)) + NCHAR(39)'
                   WHEN 'date'             THEN N'NCHAR(39) + CONVERT(varchar(10), t.' + QUOTENAME(name) + N', 23) + NCHAR(39)'
                   WHEN 'datetime'         THEN N'NCHAR(39) + CONVERT(varchar(23), t.' + QUOTENAME(name) + N', 126) + NCHAR(39)'
                   WHEN 'smalldatetime'    THEN N'NCHAR(39) + CONVERT(varchar(23), t.' + QUOTENAME(name) + N', 126) + NCHAR(39)'
                   WHEN 'datetime2'        THEN N'NCHAR(39) + CONVERT(varchar(27), t.' + QUOTENAME(name) + N', 126) + NCHAR(39)'
                   WHEN 'datetimeoffset'   THEN N'NCHAR(39) + CONVERT(varchar(34), t.' + QUOTENAME(name) + N', 127) + NCHAR(39)'
                   WHEN 'time'             THEN N'NCHAR(39) + CONVERT(varchar(16), t.' + QUOTENAME(name) + N', 114) + NCHAR(39)'
                   WHEN 'uniqueidentifier' THEN N'NCHAR(39) + CONVERT(char(36), t.' + QUOTENAME(name) + N') + NCHAR(39)'
                   WHEN 'binary'           THEN N'CONVERT(varchar(max), t.' + QUOTENAME(name) + N', 1)'
                   WHEN 'varbinary'        THEN N'CONVERT(varchar(max), t.' + QUOTENAME(name) + N', 1)'
                   WHEN 'image'            THEN N'CONVERT(varchar(max), t.' + QUOTENAME(name) + N', 1)'
                   ELSE N'NULL'
               END
        FROM sys.dm_exec_describe_first_result_set(@SelectSql, NULL, 0);

        -- si alguna columna cae en ELSE (tipo no soportado), avisar claro
        IF EXISTS (SELECT 1 FROM @Meta WHERE Expr = N'NULL')
        BEGIN
            DECLARE @TipoMalo nvarchar(2048);

            SELECT @TipoMalo = N'Tipo de dato no soportado en ' + @Full + N': ' + STUFF((
                SELECT N', ' + QUOTENAME(Col)
                FROM @Meta
                WHERE Expr = N'NULL'
                ORDER BY Ord
                FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N'');

            THROW 50016, @TipoMalo, 1;
        END

        -- columnas nullable: si el valor es NULL, generar la palabra NULL
        UPDATE @Meta
        SET Expr = N'CASE WHEN t.' + QUOTENAME(Col) + N' IS NULL THEN ''NULL'' ELSE ' + Expr + N' END'
        WHERE EsNullable = 1;

        SELECT @Cols = STUFF((
                   SELECT N',' + QUOTENAME(Col)
                   FROM @Meta
                   ORDER BY Ord
                   FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 1, N'');

        -- expresion unica: Expr1 + N',' + Expr2 + ...
        SELECT @ValsExpr = STUFF((
                   SELECT N' + N'','' + ' + Expr
                   FROM @Meta
                   ORDER BY Ord
                   FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'),
                   1, DATALENGTH(N' + N'','' + ')/2, N'');

        -- un INSERT por fila
        SET @Sql = N'SELECT @out = STUFF(('
                 + N'SELECT CHAR(13)+CHAR(10) + N''INSERT INTO '' + @full + N'' ('' + @cols + N'') VALUES ('' + '
                 + @ValsExpr
                 + N' + N'');'''
                 + N' FROM ( ' + @SelectSql + N' ) AS t'
                 + N' FOR XML PATH(''''), TYPE).value(''.'', ''nvarchar(max)''), 1, 2, '''')';

        EXEC sp_executesql @Sql,
             N'@out nvarchar(max) OUTPUT, @full nvarchar(300), @cols nvarchar(max)',
             @out = @Inserts OUTPUT, @full = @Full, @cols = @Cols;

        IF @Inserts IS NOT NULL AND @Inserts <> N''
        BEGIN
            IF @TieneIdentity = 1
                SET @Script += N'    SET IDENTITY_INSERT ' + @Full + N' ON;' + CHAR(13)+CHAR(10);

            SET @Script += @Inserts + CHAR(13)+CHAR(10);

            IF @TieneIdentity = 1
            BEGIN
                SET @Script += N'    SET IDENTITY_INSERT ' + @Full + N' OFF;' + CHAR(13)+CHAR(10);
                SET @Reseed   += N'DBCC CHECKIDENT (''' + QUOTENAME(@Esquema) + N'.' + QUOTENAME(@Tabla) + N''', RESEED);' + CHAR(13)+CHAR(10);
                SET @CatchOff += N'    SET IDENTITY_INSERT ' + @Full + N' OFF;' + CHAR(13)+CHAR(10);
            END
        END

        FETCH NEXT FROM cur INTO @Esquema, @Tabla, @SelectSql;
    END

    CLOSE cur;
    DEALLOCATE cur;

    SET @Script += N'    COMMIT;' + CHAR(13)+CHAR(10)
                + N'END TRY' + CHAR(13)+CHAR(10)
                + N'BEGIN CATCH' + CHAR(13)+CHAR(10)
                + N'    IF @@TRANCOUNT > 0 ROLLBACK;' + CHAR(13)+CHAR(10)
                + @CatchOff
                + N'    THROW;' + CHAR(13)+CHAR(10)
                + N'END CATCH;' + CHAR(13)+CHAR(10)
                + @Reseed;
END
GO
