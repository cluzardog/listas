/* ============================================================
   ejemplos.sql
   Esquema de prueba + datos + llamadas al SP + verificacion.

   Ejecutar en la base ORIGEN, despues de crear
   dbo.usp_ExportarEntidad (usp_ExportarEntidad.sql).

   La lista de tablas de la entidad esta dentro del SP, en el
   bloque "LISTA DE TABLAS DE LA ENTIDAD". Solo lleva esquema +
   nombre de tabla; el SP calcula columnas, JOINs y filtro.

   Ajustar el USE de la base antes de correr.
   ============================================================ */

-- USE TuBaseOrigen;   -- <-- descomentar y ajustar
GO

/* ------------------------------------------------------------
   1) Esquema de prueba
   ------------------------------------------------------------ */
IF OBJECT_ID('dbo.PedidoDetalleImpuesto', 'U') IS NOT NULL DROP TABLE dbo.PedidoDetalleImpuesto;
IF OBJECT_ID('dbo.PedidoObservacion',     'U') IS NOT NULL DROP TABLE dbo.PedidoObservacion;
IF OBJECT_ID('dbo.PedidoDetalle',         'U') IS NOT NULL DROP TABLE dbo.PedidoDetalle;
IF OBJECT_ID('dbo.Pedido',                'U') IS NOT NULL DROP TABLE dbo.Pedido;
GO

CREATE TABLE dbo.Pedido (
    IdPedido    int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    IdCliente   int NOT NULL,
    Fecha       datetime NOT NULL,
    Total       decimal(18,2) NOT NULL,
    Observacion varchar(200) NULL
);

CREATE TABLE dbo.PedidoDetalle (
    IdDetalle  int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    IdPedido   int NOT NULL,
    IdProducto int NOT NULL,
    Cantidad   decimal(18,2) NOT NULL,
    Precio     decimal(18,2) NOT NULL,
    CONSTRAINT FK_PedidoDetalle_Pedido
        FOREIGN KEY (IdPedido) REFERENCES dbo.Pedido(IdPedido)
);

CREATE TABLE dbo.PedidoDetalleImpuesto (
    IdDetalleImpuesto int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    IdDetalle         int NOT NULL,
    IdImpuesto        int NOT NULL,
    Importe           decimal(18,2) NOT NULL,
    CONSTRAINT FK_PedidoDetalleImpuesto_Detalle
        FOREIGN KEY (IdDetalle) REFERENCES dbo.PedidoDetalle(IdDetalle)
);

CREATE TABLE dbo.PedidoObservacion (
    IdPedido int NOT NULL,
    Fecha    datetime NOT NULL,
    Texto    nvarchar(400) NULL,
    CONSTRAINT FK_PedidoObservacion_Pedido
        FOREIGN KEY (IdPedido) REFERENCES dbo.Pedido(IdPedido)
);
GO

/* ------------------------------------------------------------
   2) Datos de ejemplo
   ------------------------------------------------------------ */
DECLARE @idPedido int, @idDetalle1 int, @idDetalle2 int;

INSERT dbo.Pedido (IdCliente, Fecha, Total, Observacion)
VALUES (77, '2026-11-01T10:15:00', 1500.50, 'Pedido de ejemplo');

SET @idPedido = SCOPE_IDENTITY();

INSERT dbo.PedidoDetalle (IdPedido, IdProducto, Cantidad, Precio)
VALUES (@idPedido, 5, 2, 750.25);
SET @idDetalle1 = SCOPE_IDENTITY();

INSERT dbo.PedidoDetalle (IdPedido, IdProducto, Cantidad, Precio)
VALUES (@idPedido, 8, 1, 0.00);
SET @idDetalle2 = SCOPE_IDENTITY();

INSERT dbo.PedidoDetalleImpuesto (IdDetalle, IdImpuesto, Importe)
VALUES (@idDetalle1, 3, 105.00),
       (@idDetalle2, 3,   0.00);

INSERT dbo.PedidoObservacion (IdPedido, Fecha, Texto)
VALUES (@idPedido, '2026-11-01T10:20:00', N'Cliente pidio factura A');

-- segundo pedido, para probar varios IDs
DECLARE @idPedido2 int, @idDetalle3 int;

INSERT dbo.Pedido (IdCliente, Fecha, Total, Observacion)
VALUES (88, '2026-11-02T09:00:00', 300.00, NULL);

SET @idPedido2 = SCOPE_IDENTITY();

INSERT dbo.PedidoDetalle (IdPedido, IdProducto, Cantidad, Precio)
VALUES (@idPedido2, 5, 1, 300.00);
SET @idDetalle3 = SCOPE_IDENTITY();

INSERT dbo.PedidoDetalleImpuesto (IdDetalle, IdImpuesto, Importe)
VALUES (@idDetalle3, 3, 21.00);

SELECT IdPedido, IdCliente, Fecha, Total FROM dbo.Pedido ORDER BY IdPedido;
GO

/* ------------------------------------------------------------
   3) Llamada al SP para un ID

   El SP tiene hardcodeada esta lista (solo esquema + tabla,
   la primera es la raiz):

       INSERT INTO @Tablas (Esquema, Tabla) VALUES
       (N'dbo', N'Pedido'),
       (N'dbo', N'PedidoDetalle'),
       (N'dbo', N'PedidoDetalleImpuesto'),
       (N'dbo', N'PedidoObservacion');

   y arma solo los SELECT. Por ejemplo, para la tabla nieta:

       SELECT t0.[IdDetalleImpuesto] AS [IdDetalleImpuesto],
              t0.[IdDetalle]         AS [IdDetalle],
              t0.[IdImpuesto]        AS [IdImpuesto],
              t0.[Importe]           AS [Importe]
       FROM [dbo].[PedidoDetalleImpuesto] AS t0
       JOIN [dbo].[PedidoDetalle] AS t1 ON t1.[IdDetalle] = t0.[IdDetalle]
       JOIN [dbo].[Pedido]        AS t2 ON t2.[IdPedido]  = t1.[IdPedido]
       WHERE t2.[IdPedido] = {ID}
   ------------------------------------------------------------ */
SET NOCOUNT ON;
SET TEXTSIZE 2147483647;   -- evita truncamiento del nvarchar(max)

DECLARE @script nvarchar(max);

EXEC dbo.usp_ExportarEntidad
     @IdEntidad = 1,       -- <-- cambiar por el IdPedido a exportar
     @Script    = @script OUTPUT;

SELECT @script AS ScriptGenerado;
GO

/* ------------------------------------------------------------
   4) Ejemplo de lo que devuelve el SP (aproximado)

   Los IDs dependen de los datos generados. El orden de las
   tablas lo calcula solo el SP segun las FK.
   ------------------------------------------------------------ */
/*
-- Entidad Id=1  Generado 2026-11-12 10:00:00
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRAN;
    SET IDENTITY_INSERT [dbo].[Pedido] ON;
INSERT INTO [dbo].[Pedido] ([IdPedido],[IdCliente],[Fecha],[Total],[Observacion]) VALUES (1,77,'2026-11-01T10:15:00.000',1500.50,N'Pedido de ejemplo');
    SET IDENTITY_INSERT [dbo].[Pedido] OFF;
    SET IDENTITY_INSERT [dbo].[PedidoDetalle] ON;
INSERT INTO [dbo].[PedidoDetalle] ([IdDetalle],[IdPedido],[IdProducto],[Cantidad],[Precio]) VALUES (1,1,5,2.00,750.25);
INSERT INTO [dbo].[PedidoDetalle] ([IdDetalle],[IdPedido],[IdProducto],[Cantidad],[Precio]) VALUES (2,1,8,1.00,0.00);
    SET IDENTITY_INSERT [dbo].[PedidoDetalle] OFF;
    SET IDENTITY_INSERT [dbo].[PedidoDetalleImpuesto] ON;
INSERT INTO [dbo].[PedidoDetalleImpuesto] ([IdDetalleImpuesto],[IdDetalle],[IdImpuesto],[Importe]) VALUES (1,1,3,105.00);
INSERT INTO [dbo].[PedidoDetalleImpuesto] ([IdDetalleImpuesto],[IdDetalle],[IdImpuesto],[Importe]) VALUES (2,2,3,0.00);
    SET IDENTITY_INSERT [dbo].[PedidoDetalleImpuesto] OFF;
INSERT INTO [dbo].[PedidoObservacion] ([IdPedido],[Fecha],[Texto]) VALUES (1,'2026-11-01T10:20:00.000',N'Cliente pidio factura A');
    COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    SET IDENTITY_INSERT [dbo].[Pedido] OFF;
    SET IDENTITY_INSERT [dbo].[PedidoDetalle] OFF;
    SET IDENTITY_INSERT [dbo].[PedidoDetalleImpuesto] OFF;
    THROW;
END CATCH;
DBCC CHECKIDENT ('[dbo].[Pedido]', RESEED);
DBCC CHECKIDENT ('[dbo].[PedidoDetalle]', RESEED);
DBCC CHECKIDENT ('[dbo].[PedidoDetalleImpuesto]', RESEED);
*/
GO

/* ------------------------------------------------------------
   5) Ejecucion en la base DESTINO

   Opcion A: pegar el script generado en SSMS y ejecutarlo.
   Opcion B: modo SQLCMD en SSMS (Query -> SQLCMD Mode) y usar :r

   Si hay triggers de auditoria y no queres que se disparen,
   descomentar el DISABLE/ENABLE.
   ------------------------------------------------------------ */
/*
USE TuBaseDestino;
GO

-- DISABLE TRIGGER ALL ON DATABASE;

-- :r "C:\Export\Pedido_1.sql"

-- ENABLE TRIGGER ALL ON DATABASE;
*/
GO

/* ------------------------------------------------------------
   6) Verificacion en el destino
   ------------------------------------------------------------ */
/*
USE TuBaseDestino;
GO

SELECT * FROM dbo.Pedido             WHERE IdPedido = 1;
SELECT * FROM dbo.PedidoDetalle       WHERE IdPedido = 1;
SELECT * FROM dbo.PedidoObservacion   WHERE IdPedido = 1;
SELECT * FROM dbo.PedidoDetalleImpuesto
 WHERE IdDetalle IN (SELECT IdDetalle FROM dbo.PedidoDetalle WHERE IdPedido = 1);

-- NORESEED no modifica nada: solo muestra el identity actual
DBCC CHECKIDENT ('dbo.Pedido', NORESEED);
DBCC CHECKIDENT ('dbo.PedidoDetalle', NORESEED);
DBCC CHECKIDENT ('dbo.PedidoDetalleImpuesto', NORESEED);
*/
GO

/* ------------------------------------------------------------
   7) Opcional: guardar el script en una tabla de log
   ------------------------------------------------------------ */
IF OBJECT_ID('dbo.ExportLog', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ExportLog (
        IdLog     int IDENTITY(1,1) PRIMARY KEY,
        Nombre    varchar(100) NOT NULL,
        IdEntidad int NOT NULL,
        Fecha     datetime2 NOT NULL DEFAULT SYSDATETIME(),
        Script    nvarchar(max) NOT NULL
    );
END
GO

DECLARE @s nvarchar(max);

EXEC dbo.usp_ExportarEntidad
     @IdEntidad = 1,
     @Script    = @s OUTPUT;

INSERT dbo.ExportLog (Nombre, IdEntidad, Script)
VALUES ('Pedido', 1, @s);

SELECT IdLog, Nombre, IdEntidad, Fecha, LEN(Script) AS LargoScript
FROM dbo.ExportLog
ORDER BY IdLog DESC;
GO

/* ------------------------------------------------------------
   8) Varios IDs en un solo script
   ------------------------------------------------------------ */
SET NOCOUNT ON;
SET TEXTSIZE 2147483647;

DECLARE @script nvarchar(max) = N'';
DECLARE @id int, @parte nvarchar(max);

DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
    SELECT IdPedido FROM dbo.Pedido ORDER BY IdPedido;

OPEN cur;
FETCH NEXT FROM cur INTO @id;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @parte = NULL;

    EXEC dbo.usp_ExportarEntidad
         @IdEntidad = @id,
         @Script    = @parte OUTPUT;

    SET @script += @parte + CHAR(13) + CHAR(10);

    FETCH NEXT FROM cur INTO @id;
END

CLOSE cur;
DEALLOCATE cur;

SELECT @script AS ScriptVariosIds;
GO
